(function($) {
'use strict';
   
     $('.counter_number').counterUp({
        time: 1500
    });
    
    $('.venobox').venobox();

   
    //====================================================================//
    // Banner slider part
    //====================================================================//
   
    $('.tp-banner').revolution({
           delay: 7000,
           startwidth: 1920,            //default:1170
           startheight: 500,
           onHoverStop: "off",
           touchenabled: "on",
           hideThumbs: 0,
           navigationType:"bullet",				// bullet, thumb, none
           navigationStyle: "round",				// round,square,navbar,round-old,square-old,navbar-old, or any from the list in the docu (choose between 50+ different item), custom
           navigationHAlign: "center",				// Vertical Align top,center,bottom
           navigationVAlign: "bottom",					// Horizontal Align left,center,right
           navigationVOffset: 30,
       });
})(jQuery);



